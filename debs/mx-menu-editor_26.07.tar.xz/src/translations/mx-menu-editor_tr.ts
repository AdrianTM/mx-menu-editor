<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="tr">
<context>
    <name>AddAppDialog</name>
    <message>
        <location filename="../src/addappdialog.ui" line="23"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="33"/>
        <source>Categories</source>
        <translation>Kategoriler</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="45"/>
        <source>Add category</source>
        <translation>Kategori ekle</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="59"/>
        <source>Delete category</source>
        <translation>Kategori sil</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="76"/>
        <source>Command:</source>
        <translation>Komut:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="121"/>
        <source>Save Changes</source>
        <translation>Değişiklikleri kaydet</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="128"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="166"/>
        <source>Quit dialog</source>
        <translation>Pencereyi kapat</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="169"/>
        <source>Cancel</source>
        <translation>İptal</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="176"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="194"/>
        <source>Select...</source>
        <translation>Seç...</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="201"/>
        <source>Name:</source>
        <translation>Ad:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="208"/>
        <source>Comment:</source>
        <translation>Yorum:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="215"/>
        <source>Icon:</source>
        <translation>Simge:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="222"/>
        <location filename="../src/addappdialog.cpp" line="359"/>
        <source>Set icon</source>
        <translation>Simge ayarla</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="235"/>
        <source>Run in Terminal</source>
        <translation>Uçbirimde Çalıştır</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="248"/>
        <source>Startup Notifier</source>
        <translation>Başlangıç Bildirimi</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="50"/>
        <source>Add Custom Application</source>
        <translation>Özel Uygulama Ekle</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="152"/>
        <source>Comment cannot contain newlines or control characters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="173"/>
        <source>Icon path cannot contain newlines or control characters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="186"/>
        <location filename="../src/addappdialog.cpp" line="193"/>
        <location filename="../src/addappdialog.cpp" line="200"/>
        <location filename="../src/addappdialog.cpp" line="207"/>
        <location filename="../src/addappdialog.cpp" line="216"/>
        <location filename="../src/addappdialog.cpp" line="221"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="69"/>
        <source>Application name cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="74"/>
        <source>Application name is too long (maximum 255 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="114"/>
        <location filename="../src/addappdialog.cpp" line="133"/>
        <source>Command cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="119"/>
        <source>Command is too long (maximum 1024 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="125"/>
        <source>Command cannot contain newlines</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="103"/>
        <source>Warning</source>
        <translation>Uyarı</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="79"/>
        <source>Application name cannot contain newlines or control characters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="104"/>
        <source>The executable '%1' does not exist or is not in PATH.
Do you want to continue anyway?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="147"/>
        <source>Comment is too long (maximum 512 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="168"/>
        <source>Icon path is too long (maximum 512 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="216"/>
        <source>Could not create application directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="221"/>
        <source>Could not save the file</source>
        <translation>Dosya kaydedilemedi</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="272"/>
        <source>Change icon</source>
        <translation>Simgeyi değiştir</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="280"/>
        <source>Image Files (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation>Resim Dosyaları (*.png *.jpg *.bmp *.xpm *.svg)</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="294"/>
        <source>Select executable file</source>
        <translation>Çalıştırılabilir dosyayı seçin</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="340"/>
        <source>Save changes?</source>
        <translation>Değişiklikler kaydedilsin mi?</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="340"/>
        <source>Do you want to save your edits?</source>
        <translation>Düzenlemelerinizi kaydetmek istiyor musunuz?</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Kaydet</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="17"/>
        <location filename="../src/mainwindow.cpp" line="1177"/>
        <source>MX Menu Editor</source>
        <translation>MX Menü Düzenleyici</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="34"/>
        <source>Advanced Editor</source>
        <translation>Gelişmiş Düzenleyici</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Categories and applications</source>
        <translation>Kategoriler ve uygulamalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="64"/>
        <source>Search by category, name, or executable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="92"/>
        <source>Add custom application</source>
        <translation>Özel uygulama ekle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="106"/>
        <source>Options</source>
        <translation>Seçenekler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <source>Run in terminal</source>
        <translation>Uçbirimde çalıştır</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="125"/>
        <source>Hide</source>
        <translation>Gizle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="135"/>
        <source>Notify startup</source>
        <translation>Başlangıçta bildir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="158"/>
        <source>Quick Editor</source>
        <translation>Çabuk düzenleyici</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="170"/>
        <source>Comment:</source>
        <translation>Yorum:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <location filename="../src/mainwindow.cpp" line="529"/>
        <location filename="../src/mainwindow.cpp" line="535"/>
        <location filename="../src/mainwindow.cpp" line="781"/>
        <source>Restore original item</source>
        <translation>Özgün öğeyi geri yükle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="191"/>
        <source>Command:</source>
        <translation>Komut:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="201"/>
        <source>Select...</source>
        <translation>Seç...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="215"/>
        <source>Name:</source>
        <translation>Ad:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <source>Icon</source>
        <translation>Simge</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="276"/>
        <source>Change icon</source>
        <translation>Simgeyi değiştir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="290"/>
        <source>Categories</source>
        <translation>Kategoriler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="302"/>
        <source>Add</source>
        <translation>Ekle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="316"/>
        <location filename="../src/mainwindow.cpp" line="532"/>
        <source>Delete</source>
        <translation>Sil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="382"/>
        <source>Quit application</source>
        <translation>Uygulamadan çık</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="385"/>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Display help</source>
        <translation>Yardımı görüntüle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Help</source>
        <translation>Yardım</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="443"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="462"/>
        <source>Save Changes</source>
        <translation>Değişiklikleri kaydet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="469"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="504"/>
        <source>About this application</source>
        <translation>Uygulama hakkında</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="507"/>
        <source>About...</source>
        <translation>Hakkında...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="514"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="743"/>
        <source>Select executable file</source>
        <translation>Çalıştırılabilir dosyayı seçin</translation>
    </message>
    <message>
        <source>Image Files (*.png *.jpg *.bmp *.xpm)</source>
        <translation type="vanished">Resim Dosyaları  (*.png *.jpg *.bmp *.xpm)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="823"/>
        <source>Image Files (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation>Resim Dosyaları (*.png *.jpg *.bmp *.xpm *.svg)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="993"/>
        <source>Choose category</source>
        <translation>Kategori seçin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1007"/>
        <location filename="../src/mainwindow.cpp" line="1183"/>
        <source>Cancel</source>
        <translation>İptal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1008"/>
        <source>OK</source>
        <translation>Tamam</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="833"/>
        <location filename="../src/mainwindow.cpp" line="847"/>
        <location filename="../src/mainwindow.cpp" line="862"/>
        <location filename="../src/mainwindow.cpp" line="877"/>
        <location filename="../src/mainwindow.cpp" line="1123"/>
        <location filename="../src/mainwindow.cpp" line="1129"/>
        <location filename="../src/mainwindow.cpp" line="1207"/>
        <location filename="../src/mainwindow.cpp" line="1211"/>
        <location filename="../src/mainwindow.cpp" line="1282"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="833"/>
        <source>Icon path cannot contain newlines or control characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="847"/>
        <source>Application name cannot contain newlines or control characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="862"/>
        <source>Command cannot contain newlines or control characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="877"/>
        <source>Comment cannot contain newlines or control characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1123"/>
        <source>Could not create the applications directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1129"/>
        <source>Could not save the file</source>
        <translation>Dosya kaydedilemedi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1176"/>
        <source>About MX Menu Editor</source>
        <translation>MX Menü Düzenleyici Hakkında</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1177"/>
        <source>Version: </source>
        <translation>Sürüm:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1178"/>
        <source>Program for editing Xfce menu</source>
        <translation>Xfce menüsünü düzenleme programı</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1180"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1181"/>
        <source>License</source>
        <translation>Lisans</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1182"/>
        <source>Changelog</source>
        <translation>Değişim günlüğü</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1190"/>
        <source>%1 License</source>
        <translation>%1 Lisans</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1207"/>
        <source>Could not read the changelog (timed out).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1211"/>
        <source>Could not read the changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1216"/>
        <source>&amp;Close</source>
        <translation>&amp;Kapat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1237"/>
        <source>MX Menu Editor Help</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1256"/>
        <source>Save changes?</source>
        <translation>Değişiklikler kaydedilsin mi?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1256"/>
        <source>Do you want to save your edits?</source>
        <translation>Düzenlemelerinizi kaydetmek istiyor musunuz?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1282"/>
        <source>Could not restore the application: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="68"/>
        <source>You must run this program as normal user.</source>
        <translation>Bu programı normal kullanıcı olarak çalıştırmalısınız.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/docviewer.cpp" line="50"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/docviewer.cpp" line="53"/>
        <source>&amp;Close</source>
        <translation>&amp;Kapat</translation>
    </message>
</context>
</TS>