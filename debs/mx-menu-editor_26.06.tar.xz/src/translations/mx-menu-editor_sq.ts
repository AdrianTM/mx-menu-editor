<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sq">
<context>
    <name>AddAppDialog</name>
    <message>
        <location filename="../src/addappdialog.ui" line="23"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="33"/>
        <source>Categories</source>
        <translation>Kategori</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="45"/>
        <source>Add category</source>
        <translation>Shtoni kategori</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="59"/>
        <source>Delete category</source>
        <translation>Fshini kategori</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="76"/>
        <source>Command:</source>
        <translation>Urdhër:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="121"/>
        <source>Save Changes</source>
        <translation>Ruaji Ndryshimet</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="128"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="166"/>
        <source>Quit dialog</source>
        <translation>Dialog daljeje</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="169"/>
        <source>Cancel</source>
        <translation>Anuloje</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="176"/>
        <source>Alt+N</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="194"/>
        <source>Select...</source>
        <translation>Përzgjidhni…</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="201"/>
        <source>Name:</source>
        <translation>Emër:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="208"/>
        <source>Comment:</source>
        <translation>Koment:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="215"/>
        <source>Icon:</source>
        <translation>Ikonë:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="222"/>
        <location filename="../src/addappdialog.cpp" line="369"/>
        <source>Set icon</source>
        <translation>Caktoni ikonë</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="235"/>
        <source>Run in Terminal</source>
        <translation>Xhiroje në Terminal</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="248"/>
        <source>Startup Notifier</source>
        <translation>Njoftues Nisjesh</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="38"/>
        <source>Add Custom Application</source>
        <translation>Shtoni Aplikacion Vetjak</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="268"/>
        <location filename="../src/addappdialog.cpp" line="275"/>
        <location filename="../src/addappdialog.cpp" line="282"/>
        <location filename="../src/addappdialog.cpp" line="289"/>
        <location filename="../src/addappdialog.cpp" line="298"/>
        <location filename="../src/addappdialog.cpp" line="303"/>
        <source>Error</source>
        <translation>Gabim</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="53"/>
        <source>Application name cannot be empty</source>
        <translation>Emri i aplikacionit s’mund të jetë i zbrazët</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="58"/>
        <source>Application name is too long (maximum 255 characters)</source>
        <translation>Emri i aplikacionit është shumë i gjatë (255 shenja e shumta)</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="65"/>
        <source>Application name cannot contain newlines</source>
        <translation>Emri i aplikacionit s’mund të përmbajë simbole rreshti të ri</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="69"/>
        <source>Application name contains invalid control characters</source>
        <translation>Emri i aplikacionit përmban shenja të pavlefshme kontrolli</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="81"/>
        <location filename="../src/addappdialog.cpp" line="102"/>
        <source>Command cannot be empty</source>
        <translation>Urdhri s’mund të jetë i zbrazët</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="86"/>
        <source>Command is too long (maximum 1024 characters)</source>
        <translation>Urdhri është shumë i gjatë (1024 shenja e shumta)</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="92"/>
        <source>Command cannot contain newlines</source>
        <translation>Urdhri s’mund të përmbajë simbole rreshti të ri</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="108"/>
        <source>Warning</source>
        <translation>Kujdes</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="109"/>
        <source>The executable '%1' does not exist or is not in PATH.
Do you want to continue anyway?</source>
        <translation>I ekzekutueshmi &apos;%1&apos; s’ekziston, ose s’është në PATH.
Doni të vazhdoni, sido qoftë?</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="122"/>
        <source>Comment is too long (maximum 512 characters)</source>
        <translation>Komenti është shumë i gjatë (512 shenja e shumta)</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="129"/>
        <source>Comment cannot contain newlines</source>
        <translation>Komenti s’mund të përmbajë simbole rreshti të ri</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="133"/>
        <source>Comment contains invalid control characters</source>
        <translation>Komenti përmban shenja të pavlefshme kontrolli</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="150"/>
        <source>Icon path is too long (maximum 512 characters)</source>
        <translation>Shtegu i ikonës është shumë i gjatë (512 shenja e shumta)</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="157"/>
        <source>Icon path cannot contain newlines</source>
        <translation>Shtegu i ikonës s’mund të përmbajë simbole rreshti të ri</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="161"/>
        <source>Icon path contains invalid control characters</source>
        <translation>Shtegu i ikonës përmban shenja të pavlefshme kontrolli</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="298"/>
        <source>Could not create application directory</source>
        <translation>S’u krijua dot drejtori aplikacioni</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="303"/>
        <source>Could not save the file</source>
        <translation>S’u ruajt dot kartela</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="350"/>
        <source>Save changes?</source>
        <translation>Të ruhen ndryshimet?</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="350"/>
        <source>Do you want to save your edits?</source>
        <translation>Doni të ruhen përpunimet tuaja?</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Ruaje</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="17"/>
        <location filename="../src/mainwindow.cpp" line="1333"/>
        <source>MX Menu Editor</source>
        <translation>Përpunues MX Menush</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="34"/>
        <source>Advanced Editor</source>
        <translation>Përpunues i Thelluar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Categories and applications</source>
        <translation>Kategori dhe aplikacione</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="64"/>
        <source>Search by category, name, or executable</source>
        <translation>Kërkoni sipas kategorie, emri, ose të ekzekutueshmi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="92"/>
        <source>Add custom application</source>
        <translation>Shtoni aplikacion vetjak</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="106"/>
        <source>Options</source>
        <translation>Mundësi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <source>Run in terminal</source>
        <translation>Xhiroje në terminal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="125"/>
        <source>Hide</source>
        <translation>Fshihe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="135"/>
        <source>Notify startup</source>
        <translation>Njofto gjatë nisjes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="158"/>
        <source>Quick Editor</source>
        <translation>Përpunues i Shpejtë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="170"/>
        <source>Comment:</source>
        <translation>Koment:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <location filename="../src/mainwindow.cpp" line="565"/>
        <location filename="../src/mainwindow.cpp" line="571"/>
        <location filename="../src/mainwindow.cpp" line="834"/>
        <source>Restore original item</source>
        <translation>Rikthe objektin origjinal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="191"/>
        <source>Command:</source>
        <translation>Urdhër:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="201"/>
        <source>Select...</source>
        <translation>Përzgjidhni…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="215"/>
        <source>Name:</source>
        <translation>Emër:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <source>Icon</source>
        <translation>Ikonë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="276"/>
        <location filename="../src/mainwindow.cpp" line="898"/>
        <source>Change icon</source>
        <translation>Ndrysho ikonë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="290"/>
        <source>Categories</source>
        <translation>Kategori</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="302"/>
        <source>Add</source>
        <translation>Shto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="316"/>
        <location filename="../src/mainwindow.cpp" line="568"/>
        <source>Delete</source>
        <translation>Fshije</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="382"/>
        <source>Quit application</source>
        <translation>Mbylle aplikacionin</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="385"/>
        <source>Close</source>
        <translation>Mbylle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>Alt+N</source>
        <translation>Alt+M</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Display help</source>
        <translation>Shfaq ndihmë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Help</source>
        <translation>Ndihmë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="443"/>
        <source>Alt+H</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="462"/>
        <source>Save Changes</source>
        <translation>Ruaji Ndryshimet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="469"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="504"/>
        <source>About this application</source>
        <translation>Mbi këtë aplikacion</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="507"/>
        <source>About...</source>
        <translation>Mbi…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="514"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="792"/>
        <source>Select executable file</source>
        <translation>Përzgjidhni kartelë të ekzekutueshme</translation>
    </message>
    <message>
        <source>Image Files (*.png *.jpg *.bmp *.xpm)</source>
        <translation type="vanished">Kartela Figurash (*.png *.jpg *.bmp *.xpm)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="876"/>
        <source>Image Files (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation>Kartela Figurë (*.png *.jpg *.bmp *.xpm *.svg)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1113"/>
        <source>Choose category</source>
        <translation>Zgjidhni kategori</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1127"/>
        <location filename="../src/mainwindow.cpp" line="1339"/>
        <source>Cancel</source>
        <translation>Anuloje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1128"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1247"/>
        <source>Warning</source>
        <translation>Kujdes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1248"/>
        <source>The executable '%1' does not exist or is not in PATH.
Do you want to continue anyway?</source>
        <translation>I ekzekutueshmi &apos;%1&apos; s’ekziston, ose sështë te PATH.
Doni të vazhdohet, sido qoftë?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1289"/>
        <location filename="../src/mainwindow.cpp" line="1295"/>
        <source>Error</source>
        <translation>Gabim</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1289"/>
        <source>Could not create the applications directory</source>
        <translation>S’u krijua dot drejtori aplikacionesh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1295"/>
        <source>Could not save the file</source>
        <translation>S’u ruajt dot kartela</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1332"/>
        <source>About MX Menu Editor</source>
        <translation>Mbi Përpunues MX Menush</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1333"/>
        <source>Version: </source>
        <translation>Version: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1334"/>
        <source>Program for editing Xfce menu</source>
        <translation>Program për përpunim menush Xfce-je</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1336"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Të drejta kopjimi (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1337"/>
        <source>License</source>
        <translation>Licencë</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1338"/>
        <source>Changelog</source>
        <translation>Regjistër ndryshimesh</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1368"/>
        <source>&amp;Close</source>
        <translation>&amp;Mbylle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1416"/>
        <source>Save changes?</source>
        <translation>Të ruhen ndryshimet?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1416"/>
        <source>Do you want to save your edits?</source>
        <translation>Doni të ruhen përpunimet tuaja?</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="68"/>
        <source>You must run this program as normal user.</source>
        <translation>Këtë program duhet ta xhironi si përdorues i thjeshtë.</translation>
    </message>
</context>
</TS>