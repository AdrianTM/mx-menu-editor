<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ka">
<context>
    <name>AddAppDialog</name>
    <message>
        <location filename="../src/addappdialog.ui" line="23"/>
        <source>Dialog</source>
        <translation>დიალოგი</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="33"/>
        <source>Categories</source>
        <translation>კატეგორიები</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="45"/>
        <source>Add category</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="59"/>
        <source>Delete category</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="76"/>
        <source>Command:</source>
        <translation>ბრძანება:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="121"/>
        <source>Save Changes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="128"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="166"/>
        <source>Quit dialog</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="169"/>
        <source>Cancel</source>
        <translation>გაუქმება</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="176"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="194"/>
        <source>Select...</source>
        <translation>აირჩიეთ...</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="201"/>
        <source>Name:</source>
        <translation>სახელი:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="208"/>
        <source>Comment:</source>
        <translation>კომენტარი:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="215"/>
        <source>Icon:</source>
        <translation>ხატულა:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="222"/>
        <location filename="../src/addappdialog.cpp" line="369"/>
        <source>Set icon</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="235"/>
        <source>Run in Terminal</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="248"/>
        <source>Startup Notifier</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="38"/>
        <source>Add Custom Application</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="268"/>
        <location filename="../src/addappdialog.cpp" line="275"/>
        <location filename="../src/addappdialog.cpp" line="282"/>
        <location filename="../src/addappdialog.cpp" line="289"/>
        <location filename="../src/addappdialog.cpp" line="298"/>
        <location filename="../src/addappdialog.cpp" line="303"/>
        <source>Error</source>
        <translation>შეცდომა</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="53"/>
        <source>Application name cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="58"/>
        <source>Application name is too long (maximum 255 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="65"/>
        <source>Application name cannot contain newlines</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="69"/>
        <source>Application name contains invalid control characters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="81"/>
        <location filename="../src/addappdialog.cpp" line="102"/>
        <source>Command cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="86"/>
        <source>Command is too long (maximum 1024 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="92"/>
        <source>Command cannot contain newlines</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="108"/>
        <source>Warning</source>
        <translation>გაფრთხილება</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="109"/>
        <source>The executable '%1' does not exist or is not in PATH.
Do you want to continue anyway?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="122"/>
        <source>Comment is too long (maximum 512 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="129"/>
        <source>Comment cannot contain newlines</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="133"/>
        <source>Comment contains invalid control characters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="150"/>
        <source>Icon path is too long (maximum 512 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="157"/>
        <source>Icon path cannot contain newlines</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="161"/>
        <source>Icon path contains invalid control characters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="298"/>
        <source>Could not create application directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="303"/>
        <source>Could not save the file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="350"/>
        <source>Save changes?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="350"/>
        <source>Do you want to save your edits?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">შენახვა</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="17"/>
        <location filename="../src/mainwindow.cpp" line="1333"/>
        <source>MX Menu Editor</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="34"/>
        <source>Advanced Editor</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Categories and applications</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="64"/>
        <source>Search by category, name, or executable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="92"/>
        <source>Add custom application</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="106"/>
        <source>Options</source>
        <translation>მორგება</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <source>Run in terminal</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="125"/>
        <source>Hide</source>
        <translation>დამალვა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="135"/>
        <source>Notify startup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="158"/>
        <source>Quick Editor</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="170"/>
        <source>Comment:</source>
        <translation>კომენტარი:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <location filename="../src/mainwindow.cpp" line="565"/>
        <location filename="../src/mainwindow.cpp" line="571"/>
        <location filename="../src/mainwindow.cpp" line="834"/>
        <source>Restore original item</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="191"/>
        <source>Command:</source>
        <translation>ბრძანება:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="201"/>
        <source>Select...</source>
        <translation>აირჩიეთ...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="215"/>
        <source>Name:</source>
        <translation>სახელი:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <source>Icon</source>
        <translation>ხატულა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="276"/>
        <location filename="../src/mainwindow.cpp" line="898"/>
        <source>Change icon</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="290"/>
        <source>Categories</source>
        <translation>კატეგორიები</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="302"/>
        <source>Add</source>
        <translation>დამატება</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="316"/>
        <location filename="../src/mainwindow.cpp" line="568"/>
        <source>Delete</source>
        <translation>წაშლა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="382"/>
        <source>Quit application</source>
        <translation>აპლიკაციიდან გასვლა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="385"/>
        <source>Close</source>
        <translation>დახურვა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Display help</source>
        <translation>დახმარების ჩვენება</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Help</source>
        <translation>დახმარება</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="443"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="462"/>
        <source>Save Changes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="469"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="504"/>
        <source>About this application</source>
        <translation>ამ აპლიკაციის შესახებ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="507"/>
        <source>About...</source>
        <translation>შესახებ...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="514"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="792"/>
        <source>Select executable file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Image Files (*.png *.jpg *.bmp *.xpm)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="876"/>
        <source>Image Files (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1113"/>
        <source>Choose category</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1127"/>
        <location filename="../src/mainwindow.cpp" line="1339"/>
        <source>Cancel</source>
        <translation>გაუქმება</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1128"/>
        <source>OK</source>
        <translation>დიახ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1247"/>
        <source>Warning</source>
        <translation>გაფრთხილება</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1248"/>
        <source>The executable '%1' does not exist or is not in PATH.
Do you want to continue anyway?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1289"/>
        <location filename="../src/mainwindow.cpp" line="1295"/>
        <source>Error</source>
        <translation>შეცდომა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1289"/>
        <source>Could not create the applications directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1295"/>
        <source>Could not save the file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1332"/>
        <source>About MX Menu Editor</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1333"/>
        <source>Version: </source>
        <translation>ვერსია:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1334"/>
        <source>Program for editing Xfce menu</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1336"/>
        <source>Copyright (c) MX Linux</source>
        <translation>(c) MX Linux საავტორო ფულებები დაცულია</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1337"/>
        <source>License</source>
        <translation>ლიცენზია</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1338"/>
        <source>Changelog</source>
        <translation>ცვლილებების ჟურნალი</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1368"/>
        <source>&amp;Close</source>
        <translation>&amp;დახურვა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1416"/>
        <source>Save changes?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1416"/>
        <source>Do you want to save your edits?</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="68"/>
        <source>You must run this program as normal user.</source>
        <translation>ეს პროგრამა ნორმალური მომხმარებლით უნდა გაუშვათ.</translation>
    </message>
</context>
</TS>