<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es_ES">
<context>
    <name>AddAppDialog</name>
    <message>
        <location filename="../src/addappdialog.ui" line="23"/>
        <source>Dialog</source>
        <translation>Diálogo</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="33"/>
        <source>Categories</source>
        <translation>Categorías</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="45"/>
        <source>Add category</source>
        <translation>Añadir categorías</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="59"/>
        <source>Delete category</source>
        <translation>Borrar categorías</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="76"/>
        <source>Command:</source>
        <translation>Orden:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="121"/>
        <source>Save Changes</source>
        <translation>Guardar cambios</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="128"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="166"/>
        <source>Quit dialog</source>
        <translation>Cerrar diálogo</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="169"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="176"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="194"/>
        <source>Select...</source>
        <translation>Seleccionar...</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="201"/>
        <source>Name:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="208"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="215"/>
        <source>Icon:</source>
        <translation>Ícono:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="222"/>
        <location filename="../src/addappdialog.cpp" line="369"/>
        <source>Set icon</source>
        <translation>Establecer ícono</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="235"/>
        <source>Run in Terminal</source>
        <translation>Ejecutar en terminal</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="248"/>
        <source>Startup Notifier</source>
        <translation>Nortificador de inicio</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="38"/>
        <source>Add Custom Application</source>
        <translation>Añadir aplicaciones personalizadas</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="268"/>
        <location filename="../src/addappdialog.cpp" line="275"/>
        <location filename="../src/addappdialog.cpp" line="282"/>
        <location filename="../src/addappdialog.cpp" line="289"/>
        <location filename="../src/addappdialog.cpp" line="298"/>
        <location filename="../src/addappdialog.cpp" line="303"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="53"/>
        <source>Application name cannot be empty</source>
        <translation>El nombre de la aplicación no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="58"/>
        <source>Application name is too long (maximum 255 characters)</source>
        <translation>El nombre de la aplicación es demasiado largo (máximo 255 caracteres)</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="65"/>
        <source>Application name cannot contain newlines</source>
        <translation>El nombre de la aplicación no puede contener saltos de línea</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="69"/>
        <source>Application name contains invalid control characters</source>
        <translation>El nombre de la aplicación contiene caracteres de control no válidos</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="81"/>
        <location filename="../src/addappdialog.cpp" line="102"/>
        <source>Command cannot be empty</source>
        <translation>El comando no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="86"/>
        <source>Command is too long (maximum 1024 characters)</source>
        <translation>El comando es demasiado largo (máximo 1024 caracteres)</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="92"/>
        <source>Command cannot contain newlines</source>
        <translation>El comando no puede contener saltos de línea</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="108"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="109"/>
        <source>The executable '%1' does not exist or is not in PATH.
Do you want to continue anyway?</source>
        <translation>El ejecutable &apos;%1&apos; no existe o no está en el PATH.
¿Desea continuar de todos modos?</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="122"/>
        <source>Comment is too long (maximum 512 characters)</source>
        <translation>El comentario es demasiado largo (máximo 512 caracteres)</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="129"/>
        <source>Comment cannot contain newlines</source>
        <translation>Los comentarios no pueden contener saltos de línea</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="133"/>
        <source>Comment contains invalid control characters</source>
        <translation>El comentario contiene caracteres de control no válidos</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="150"/>
        <source>Icon path is too long (maximum 512 characters)</source>
        <translation>La ruta del icono es demasiado larga (máximo 512 caracteres)</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="157"/>
        <source>Icon path cannot contain newlines</source>
        <translation>La ruta del icono no puede contener saltos de línea</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="161"/>
        <source>Icon path contains invalid control characters</source>
        <translation>La ruta del icono contiene caracteres de control no válidos</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="298"/>
        <source>Could not create application directory</source>
        <translation>No se pudo crear el directorio de la aplicación</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="303"/>
        <source>Could not save the file</source>
        <translation>No se pudo guardar el archivo</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="350"/>
        <source>Save changes?</source>
        <translation>¿Guardar los cambios?</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="350"/>
        <source>Do you want to save your edits?</source>
        <translation>¿Desea guardar sus cambios?</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Guardar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="17"/>
        <location filename="../src/mainwindow.cpp" line="1333"/>
        <source>MX Menu Editor</source>
        <translation>MX Editor de Menú</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="34"/>
        <source>Advanced Editor</source>
        <translation>Editor avanzado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Categories and applications</source>
        <translation>Categorías y aplicaciones</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="64"/>
        <source>Search by category, name, or executable</source>
        <translation>Buscar por categoría, nombre o ejecutable</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="92"/>
        <source>Add custom application</source>
        <translation>Añadir aplicacion personalizada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="106"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <source>Run in terminal</source>
        <translation>Ejecutar en terminal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="125"/>
        <source>Hide</source>
        <translation>Ocultar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="135"/>
        <source>Notify startup</source>
        <translation>Notificar inicio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="158"/>
        <source>Quick Editor</source>
        <translation>Editor rápido</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="170"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <location filename="../src/mainwindow.cpp" line="565"/>
        <location filename="../src/mainwindow.cpp" line="571"/>
        <location filename="../src/mainwindow.cpp" line="834"/>
        <source>Restore original item</source>
        <translation>Restaurar elemento original</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="191"/>
        <source>Command:</source>
        <translation>Orden:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="201"/>
        <source>Select...</source>
        <translation>Seleccionar...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="215"/>
        <source>Name:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <source>Icon</source>
        <translation>Ícono</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="276"/>
        <location filename="../src/mainwindow.cpp" line="898"/>
        <source>Change icon</source>
        <translation>Cambiar ícono</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="290"/>
        <source>Categories</source>
        <translation>Categorías</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="302"/>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="316"/>
        <location filename="../src/mainwindow.cpp" line="568"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="382"/>
        <source>Quit application</source>
        <translation>Salir de la aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="385"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Display help</source>
        <translation>Mostrar ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="443"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="462"/>
        <source>Save Changes</source>
        <translation>Guardar cambios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="469"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="504"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="507"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="514"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="792"/>
        <source>Select executable file</source>
        <translation>Seleccionar archivo ejecutable</translation>
    </message>
    <message>
        <source>Image Files (*.png *.jpg *.bmp *.xpm)</source>
        <translation type="vanished">Archivos de imagen (*.png *.jpg *.bmp *.xpm)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="876"/>
        <source>Image Files (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation>Archivos de imagen (*.png *.jpg *.bmp *.xpm *.svg)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1113"/>
        <source>Choose category</source>
        <translation>Elegir categoría</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1127"/>
        <location filename="../src/mainwindow.cpp" line="1339"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1128"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1247"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1248"/>
        <source>The executable '%1' does not exist or is not in PATH.
Do you want to continue anyway?</source>
        <translation>El ejecutable &apos;%1&apos; no existe o no está en el PATH.
¿Desea continuar de todos modos?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1289"/>
        <location filename="../src/mainwindow.cpp" line="1295"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1289"/>
        <source>Could not create the applications directory</source>
        <translation>No se pudo crear el directorio de las aplicaciones</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1295"/>
        <source>Could not save the file</source>
        <translation>No se pudo guardar el archivo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1332"/>
        <source>About MX Menu Editor</source>
        <translation>Acerca del MX Editor de Menú</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1333"/>
        <source>Version: </source>
        <translation>Versión: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1334"/>
        <source>Program for editing Xfce menu</source>
        <translation>Programa para editar el menú de Xfce</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1336"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1337"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1338"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1368"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1416"/>
        <source>Save changes?</source>
        <translation>¿Guardar los cambios?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1416"/>
        <source>Do you want to save your edits?</source>
        <translation>¿Desea guardar sus cambios?</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="68"/>
        <source>You must run this program as normal user.</source>
        <translation>Debe ejecutar este programa como usuario normal.</translation>
    </message>
</context>
</TS>