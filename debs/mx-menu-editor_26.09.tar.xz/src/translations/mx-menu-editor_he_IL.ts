<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="he_IL">
<context>
    <name>AddAppDialog</name>
    <message>
        <location filename="../src/addappdialog.ui" line="23"/>
        <source>Dialog</source>
        <translation>תיבת דו־שיח</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="33"/>
        <source>Categories</source>
        <translation>קטגוריות</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="45"/>
        <source>Add category</source>
        <translation>הוספת קטגוריה</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="59"/>
        <source>Delete category</source>
        <translation>מחיקת קטגוריה</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="76"/>
        <source>Command:</source>
        <translation>פקודה:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="121"/>
        <source>Save Changes</source>
        <translation>שמירת השינויים</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="128"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="166"/>
        <source>Quit dialog</source>
        <translation>יציאה מהתיבה</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="169"/>
        <source>Cancel</source>
        <translation>ביטול</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="176"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="194"/>
        <source>Select...</source>
        <translation>בחירה…</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="201"/>
        <source>Name:</source>
        <translation>שם:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="208"/>
        <source>Comment:</source>
        <translation>הערה:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="215"/>
        <source>Icon:</source>
        <translation>סמל:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="222"/>
        <location filename="../src/addappdialog.cpp" line="359"/>
        <source>Set icon</source>
        <translation>הגדרת סמל</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="235"/>
        <source>Run in Terminal</source>
        <translation>הפעלה במסוף</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="248"/>
        <source>Startup Notifier</source>
        <translation>מודיע בהפעלה</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="50"/>
        <source>Add Custom Application</source>
        <translation>הוספת יישום מותאם אישית</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="152"/>
        <source>Comment cannot contain newlines or control characters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="173"/>
        <source>Icon path cannot contain newlines or control characters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="186"/>
        <location filename="../src/addappdialog.cpp" line="193"/>
        <location filename="../src/addappdialog.cpp" line="200"/>
        <location filename="../src/addappdialog.cpp" line="207"/>
        <location filename="../src/addappdialog.cpp" line="216"/>
        <location filename="../src/addappdialog.cpp" line="221"/>
        <source>Error</source>
        <translation>שגיאה</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="69"/>
        <source>Application name cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="74"/>
        <source>Application name is too long (maximum 255 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="114"/>
        <location filename="../src/addappdialog.cpp" line="133"/>
        <source>Command cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="119"/>
        <source>Command is too long (maximum 1024 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="125"/>
        <source>Command cannot contain newlines</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="103"/>
        <source>Warning</source>
        <translation>אזהרה</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="79"/>
        <source>Application name cannot contain newlines or control characters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="104"/>
        <source>The executable '%1' does not exist or is not in PATH.
Do you want to continue anyway?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="147"/>
        <source>Comment is too long (maximum 512 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="168"/>
        <source>Icon path is too long (maximum 512 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="216"/>
        <source>Could not create application directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="221"/>
        <source>Could not save the file</source>
        <translation>לא ניתן לשמור את הקובץ</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="272"/>
        <source>Change icon</source>
        <translation>החלפת סמל</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="280"/>
        <source>Image Files (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation>קובצי תמונות (‎*.png *.jpg *.bmp *.xpm *.svg)</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="294"/>
        <source>Select executable file</source>
        <translation>בחירת קובץ הפעלה</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="340"/>
        <source>Save changes?</source>
        <translation>לשמור את השינויים?</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="340"/>
        <source>Do you want to save your edits?</source>
        <translation>לשמור את העריכות שלך?</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">שמירה</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="17"/>
        <location filename="../src/mainwindow.cpp" line="1181"/>
        <source>MX Menu Editor</source>
        <translation>עורך התפריטים של MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="34"/>
        <source>Advanced Editor</source>
        <translation>עורך מתקדם</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Categories and applications</source>
        <translation>קטגוריות ויישומים</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="64"/>
        <source>Search by category, name, or executable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="92"/>
        <source>Add custom application</source>
        <translation>הוספת יישום מותאם אישית</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="106"/>
        <source>Options</source>
        <translation>אפשרויות</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <source>Run in terminal</source>
        <translation>הרצה במסוף</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="125"/>
        <source>Hide</source>
        <translation>הסתרה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="135"/>
        <source>Notify startup</source>
        <translation>הודעה עם העלייה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="158"/>
        <source>Quick Editor</source>
        <translation>עורך מהיר</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="170"/>
        <source>Comment:</source>
        <translation>הערה:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <location filename="../src/mainwindow.cpp" line="530"/>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <location filename="../src/mainwindow.cpp" line="782"/>
        <source>Restore original item</source>
        <translation>שחזור הפריט המקורי</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="191"/>
        <source>Command:</source>
        <translation>פקודה:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="201"/>
        <source>Select...</source>
        <translation>בחירה…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="215"/>
        <source>Name:</source>
        <translation>שם:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <source>Icon</source>
        <translation>סמל</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="276"/>
        <source>Change icon</source>
        <translation>החלפת סמל</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="290"/>
        <source>Categories</source>
        <translation>קטגוריות</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="302"/>
        <source>Add</source>
        <translation>הוספה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="316"/>
        <location filename="../src/mainwindow.cpp" line="533"/>
        <source>Delete</source>
        <translation>מחיקה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="382"/>
        <source>Quit application</source>
        <translation>יציאה מהיישום</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="385"/>
        <source>Close</source>
        <translation>סגירה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Display help</source>
        <translation>הצגת עזרה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Help</source>
        <translation>עזרה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="443"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="462"/>
        <source>Save Changes</source>
        <translation>שמירת השינויים</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="469"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="504"/>
        <source>About this application</source>
        <translation>על אודות יישום זה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="507"/>
        <source>About...</source>
        <translation>על אודות…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="514"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="744"/>
        <source>Select executable file</source>
        <translation>בחירת קובץ הפעלה</translation>
    </message>
    <message>
        <source>Image Files (*.png *.jpg *.bmp *.xpm)</source>
        <translation type="vanished">קובצי תמונה (‎‎*.png‏ ‎*.jpg‏ ‎*.bmp‏ ‎*.xpm‏)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="824"/>
        <source>Image Files (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation>קובצי תמונות (‎*.png *.jpg *.bmp *.xpm *.svg)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="997"/>
        <source>Choose category</source>
        <translation>בחירת קטגוריה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1011"/>
        <location filename="../src/mainwindow.cpp" line="1187"/>
        <source>Cancel</source>
        <translation>ביטול</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1012"/>
        <source>OK</source>
        <translation>אישור</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="834"/>
        <location filename="../src/mainwindow.cpp" line="848"/>
        <location filename="../src/mainwindow.cpp" line="863"/>
        <location filename="../src/mainwindow.cpp" line="878"/>
        <location filename="../src/mainwindow.cpp" line="1127"/>
        <location filename="../src/mainwindow.cpp" line="1133"/>
        <location filename="../src/mainwindow.cpp" line="1211"/>
        <location filename="../src/mainwindow.cpp" line="1215"/>
        <location filename="../src/mainwindow.cpp" line="1286"/>
        <source>Error</source>
        <translation>שגיאה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="834"/>
        <source>Icon path cannot contain newlines or control characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="848"/>
        <source>Application name cannot contain newlines or control characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="863"/>
        <source>Command cannot contain newlines or control characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="878"/>
        <source>Comment cannot contain newlines or control characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1127"/>
        <source>Could not create the applications directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1133"/>
        <source>Could not save the file</source>
        <translation>לא ניתן לשמור את הקובץ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1180"/>
        <source>About MX Menu Editor</source>
        <translation>על אודות עורך התפריטים של MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1181"/>
        <source>Version: </source>
        <translation>גירסה:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1182"/>
        <source>Program for editing Xfce menu</source>
        <translation>תכנית לעריכת התפריט של Xfce</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1184"/>
        <source>Copyright (c) MX Linux</source>
        <translation>זכויות היוצרים (c) שמורות ל־MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1185"/>
        <source>License</source>
        <translation>רשיון</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1186"/>
        <source>Changelog</source>
        <translation>יומן שינויים</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1194"/>
        <source>%1 License</source>
        <translation>רישיון של %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1211"/>
        <source>Could not read the changelog (timed out).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1215"/>
        <source>Could not read the changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1220"/>
        <source>&amp;Close</source>
        <translation>&amp;סגירה</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1241"/>
        <source>MX Menu Editor Help</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1260"/>
        <source>Save changes?</source>
        <translation>לשמור את השינויים?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1260"/>
        <source>Do you want to save your edits?</source>
        <translation>האם ברצונך לשמור את העריכות שלך?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1286"/>
        <source>Could not restore the application: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="68"/>
        <source>You must run this program as normal user.</source>
        <translation>חובה את התכנית הזו כמשתמש רגיל.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/docviewer.cpp" line="50"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/docviewer.cpp" line="53"/>
        <source>&amp;Close</source>
        <translation>&amp;סגירה</translation>
    </message>
</context>
</TS>