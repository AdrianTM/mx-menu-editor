<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="am">
<context>
    <name>AddAppDialog</name>
    <message>
        <location filename="../src/addappdialog.ui" line="23"/>
        <source>Dialog</source>
        <translation>ንግግር</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="33"/>
        <source>Categories</source>
        <translation>ምድቦች</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="45"/>
        <source>Add category</source>
        <translation>ምድብ መጨመሪያ</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="59"/>
        <source>Delete category</source>
        <translation>ምድብ ማጥፊያ</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="76"/>
        <source>Command:</source>
        <translation>ትእዛዝ:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="121"/>
        <source>Save Changes</source>
        <translation>ለውጥ ማስቀመቻ</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="128"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="166"/>
        <source>Quit dialog</source>
        <translation>ንግግር ማጥፊያ</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="169"/>
        <source>Cancel</source>
        <translation>መሰረዣ</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="176"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="194"/>
        <source>Select...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="201"/>
        <source>Name:</source>
        <translation>ስም:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="208"/>
        <source>Comment:</source>
        <translation>አስተያየት:</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="215"/>
        <source>Icon:</source>
        <translation>ምልክት</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="222"/>
        <location filename="../src/addappdialog.cpp" line="359"/>
        <source>Set icon</source>
        <translation>ምልክት ማሰናጃ</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="235"/>
        <source>Run in Terminal</source>
        <translation>በ ተርሚናል ውስጥ ማስኬጃ</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.ui" line="248"/>
        <source>Startup Notifier</source>
        <translation>ማስታወቂያ ማስጀመሪያ</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="50"/>
        <source>Add Custom Application</source>
        <translation>መተግበሪያ ማስተካከያ መጨመሪያ</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="152"/>
        <source>Comment cannot contain newlines or control characters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="173"/>
        <source>Icon path cannot contain newlines or control characters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="186"/>
        <location filename="../src/addappdialog.cpp" line="193"/>
        <location filename="../src/addappdialog.cpp" line="200"/>
        <location filename="../src/addappdialog.cpp" line="207"/>
        <location filename="../src/addappdialog.cpp" line="216"/>
        <location filename="../src/addappdialog.cpp" line="221"/>
        <source>Error</source>
        <translation>ስህተት</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="69"/>
        <source>Application name cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="74"/>
        <source>Application name is too long (maximum 255 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="114"/>
        <location filename="../src/addappdialog.cpp" line="133"/>
        <source>Command cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="119"/>
        <source>Command is too long (maximum 1024 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="125"/>
        <source>Command cannot contain newlines</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="103"/>
        <source>Warning</source>
        <translation>ማስጠንቀቂያ</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="79"/>
        <source>Application name cannot contain newlines or control characters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="104"/>
        <source>The executable '%1' does not exist or is not in PATH.
Do you want to continue anyway?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="147"/>
        <source>Comment is too long (maximum 512 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="168"/>
        <source>Icon path is too long (maximum 512 characters)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="216"/>
        <source>Could not create application directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="221"/>
        <source>Could not save the file</source>
        <translation>ፋይል ማስቀመጥ  አልተቻለም</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="272"/>
        <source>Change icon</source>
        <translation>ምልክት መቀየሪያ</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="280"/>
        <source>Image Files (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="294"/>
        <source>Select executable file</source>
        <translation>የሚፈጸም ፋይል ይምረጡ</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="340"/>
        <source>Save changes?</source>
        <translation>ለውጦቹን ላስቀምጣቸው?</translation>
    </message>
    <message>
        <location filename="../src/addappdialog.cpp" line="340"/>
        <source>Do you want to save your edits?</source>
        <translation>እርስዎ ያረሙትን ማስቀመጥ ይፈልጋሉ?</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">ማስቀመጫ</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="17"/>
        <location filename="../src/mainwindow.cpp" line="1181"/>
        <source>MX Menu Editor</source>
        <translation>MX ዝርዝር ማረሚያ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="34"/>
        <source>Advanced Editor</source>
        <translation>የረቀቀ የ ማረሚያ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Categories and applications</source>
        <translation>መተግበሪያ እና ምድብ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="64"/>
        <source>Search by category, name, or executable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="92"/>
        <source>Add custom application</source>
        <translation>መተግበሪያ ማስተካከያ መጨመሪያ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="106"/>
        <source>Options</source>
        <translation>ምርጫዎች</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <source>Run in terminal</source>
        <translation>በ ተርሚናል ውስጥ ማስኬጃ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="125"/>
        <source>Hide</source>
        <translation>መደበቂያ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="135"/>
        <source>Notify startup</source>
        <translation>ማስታወቂያ ማስጀመሪያ </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="158"/>
        <source>Quick Editor</source>
        <translation>በፍጥነት ማረሚያ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="170"/>
        <source>Comment:</source>
        <translation>አስተያየት:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <location filename="../src/mainwindow.cpp" line="530"/>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <location filename="../src/mainwindow.cpp" line="782"/>
        <source>Restore original item</source>
        <translation>ዋናውን እቃ እንደ ነበር መመለሻ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="191"/>
        <source>Command:</source>
        <translation>ትእዛዝ:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="201"/>
        <source>Select...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="215"/>
        <source>Name:</source>
        <translation>ስም:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <source>Icon</source>
        <translation>ምልክት</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="276"/>
        <source>Change icon</source>
        <translation>ምልክት መቀየሪያ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="290"/>
        <source>Categories</source>
        <translation>ምድቦች</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="302"/>
        <source>Add</source>
        <translation>መጨመሪያ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="316"/>
        <location filename="../src/mainwindow.cpp" line="533"/>
        <source>Delete</source>
        <translation>ማጥፊያ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="382"/>
        <source>Quit application</source>
        <translation>መተግበሪያ ማጥፊያ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="385"/>
        <source>Close</source>
        <translation>መዝጊያ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Display help</source>
        <translation>እርዳታ ማሳያ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Help</source>
        <translation>እርዳታ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="443"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="462"/>
        <source>Save Changes</source>
        <translation>ለውጥ ማስቀመጫ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="469"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="504"/>
        <source>About this application</source>
        <translation>ስለዚህ መተግበሪያ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="507"/>
        <source>About...</source>
        <translation>ስለ...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="514"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="744"/>
        <source>Select executable file</source>
        <translation>የሚፈጸም ፋይል ይምረጡ</translation>
    </message>
    <message>
        <source>Image Files (*.png *.jpg *.bmp *.xpm)</source>
        <translation type="vanished">ፋይል ምስል (*.png *.jpg *.bmp *.xpm)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="824"/>
        <source>Image Files (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="997"/>
        <source>Choose category</source>
        <translation>ምድብ ይምረጡ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1011"/>
        <location filename="../src/mainwindow.cpp" line="1187"/>
        <source>Cancel</source>
        <translation>መሰረዣ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1012"/>
        <source>OK</source>
        <translation>እሺ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="834"/>
        <location filename="../src/mainwindow.cpp" line="848"/>
        <location filename="../src/mainwindow.cpp" line="863"/>
        <location filename="../src/mainwindow.cpp" line="878"/>
        <location filename="../src/mainwindow.cpp" line="1127"/>
        <location filename="../src/mainwindow.cpp" line="1133"/>
        <location filename="../src/mainwindow.cpp" line="1211"/>
        <location filename="../src/mainwindow.cpp" line="1215"/>
        <location filename="../src/mainwindow.cpp" line="1286"/>
        <source>Error</source>
        <translation>ስህተት</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="834"/>
        <source>Icon path cannot contain newlines or control characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="848"/>
        <source>Application name cannot contain newlines or control characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="863"/>
        <source>Command cannot contain newlines or control characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="878"/>
        <source>Comment cannot contain newlines or control characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1127"/>
        <source>Could not create the applications directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1133"/>
        <source>Could not save the file</source>
        <translation>ፋይል ማስቀመጥ  አልተቻለም</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1180"/>
        <source>About MX Menu Editor</source>
        <translation>MX ዝርዝር ማረሚያ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1181"/>
        <source>Version: </source>
        <translation>እትም</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1182"/>
        <source>Program for editing Xfce menu</source>
        <translation>የ Xfce ዝርዝር ማረሚያ ፕሮግራም</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1184"/>
        <source>Copyright (c) MX Linux</source>
        <translation>የ ቅጂ መብት (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1185"/>
        <source>License</source>
        <translation>ፍቃድ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1186"/>
        <source>Changelog</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1194"/>
        <source>%1 License</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1211"/>
        <source>Could not read the changelog (timed out).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1215"/>
        <source>Could not read the changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1220"/>
        <source>&amp;Close</source>
        <translation>&amp;መዝጊያ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1241"/>
        <source>MX Menu Editor Help</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1260"/>
        <source>Save changes?</source>
        <translation>ለውጦቹን ላስቀምጣቸው?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1260"/>
        <source>Do you want to save your edits?</source>
        <translation>እርስዎ ያረሙትን ማስቀመጥ ይፈልጋሉ?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1286"/>
        <source>Could not restore the application: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="68"/>
        <source>You must run this program as normal user.</source>
        <translation>እርስዎ ይህን ፕሮግራም እንደ መደበኛ ተጠቃሚ ማስኬድ አለብዎት</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/docviewer.cpp" line="50"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/docviewer.cpp" line="53"/>
        <source>&amp;Close</source>
        <translation>&amp;መዝጊያ</translation>
    </message>
</context>
</TS>